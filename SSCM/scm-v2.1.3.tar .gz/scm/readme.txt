## 服务启动、检查、监控脚本
## 版本： 2.1.2
## 作者： 赵文光
## 联系方式: 13810398818
##
## 本脚本用于服务的启动 (Start)、检查 (Check) 和监控 (Monitor) , 简称 scm
## 2.0 版本以后加入了升级辅助小工具，scmreplacefile 和 scmbak ； 并将部分功能模块化，拆分成独立的脚本存放在 scm/utils 目录下。
##
##      示例: ./startAndCheckService.sh init
##      示例: ./startAndCheckService.sh reset
##      示例：scmstart
##      示例：scmcheck
##      示例：scmcheck  nginx java
##      示例：scmlog
##      示例：scmlog xxx/xxx/nohup.out
##      示例：scmonline nacos
##      示例：scmoffline nacos
##      示例：scmstop
##      示例：scmmonitor
##      示例：scmstopmonitor
##      示例：scmhelp
##
##      辅助工具示例
##      示例：scmtel 10.116.28.153 80
##      示例：scmreplacefile dispatch-v1.1.jar dispatch-v1.2.jar
##      示例：scmbak test.html test.js
##
##
## 可用选项有 10 个
##      1）start 启动 start_shells 目录下和 startService.list 文件中的已上线的服务并检查。
##      2）stop  关闭监控；关闭所有的服务并删除 PID 文件
##      3) check 检查服务是否在运行, 如果没有参数默认查看 start_shell 下的脚本启动情况，如果有参数则检查该参数指定的进程是否运行
##      4）init 初始化（是否启动日志，是否添加到开机启动，是否生成命令别名，是否生成check脚本示例，是否生成启动脚本连接生成工具，是否设置设置JAVA环境变量，在PATH变量里添加 utils 目录）
##      5）reset 关闭日志功能，删除日志文件，清除工作目录设置，删除“启动脚本目录”和“检查脚本目录”，删除开机启动项，删除命令别名,在PATH变量里删除 utils 目录，
##      6）log 如果没有参数，默认查看 logs/check_result.log 最后100行日志, 也可以指定要查看的日志文件
##      7）monitor 在后台运行监控进程服务
##      8）stopmonitor 关闭后台监控进程
##      9）offline 服务维护时使用。将 start_sheels 启动目录里面的脚本转换成隐藏文件。并杀死该脚本启动的进程 （只能下线一个服务，如果想要下线全部请用 stop选项）
##      10）online 将 offline 隐藏的文件恢复，并启动该服务（只能上线一个服务）
##      如果没有使用参数默认使用 start
##
##
## 辅助工具
##      已独立的脚本存放在 scm/utils 目录下
##      常用工具有三个 scmtel 、scmbak 和 scmreplacefile
##
## 
## 添加更多的启动服务有二种方法
##      1）在 startServices.list 添加服务（服务需要多实例的情况下使用）
##      2）编写启动脚本放在 “start_shells” ；或者直接使用 ln 命令在“start_shells”目录下创建连接
##      特别提示: 1） utils 目录下的 .createScript.sh 程序能辅助创建开机脚本
##                2） start_shells 目录下的脚本名称必须是启动的服务在 ps 命令里能够查找到的唯一标识符。（详见文件结尾）
## 
##
## 添加检测方法有两种
##      1）在 start_shells 目录下的脚本会被检测。如果开启监控，该进程没有启动会尝试重新启动
##      2）在 “check_shells” 目录下编写自定义检测脚本(注意，检测脚本是有格式要求的。请参考demo.sh文件)
##      特别提示：在使用 init 选项初始化时， 可以在 check_shells 目录下生成 .demo.sh 文件
##
## 
## 注意 1）如果移动 scm 工具需要先 reset 再 init
##        2）如果升级，停掉监控服务后，使用 reset 重置scm配置（根据提示保留原来的启动脚本文件）, 解压 tar 包，覆盖原目录，再次使用 init 初始化；断开连接，重新登陆系统。（如果有需要）重启监控服务
##        3）如果没有按照正常流程 reset 和 init 导致更新有问题，删除 /etc/systemd/system/multi-user.target.wants/scm.service 和 /usr/lib/systemd/system/scm.service ，并重新设置 startAndCheckServices-withMonitor.sh 文件中的 work_dir="./"；然后重新 init 初始化
##
##
## utils 目录下的 alarm 脚本会在监控工具发现被监控的服务运行不正常，或者被监控的服务恢复上线的时候调用。会传出三组信息：$1 检测时间; $2 进程恢复上线或者运行不正常; $3及其后面的参数 服务名。
##
##
## 启动脚本的命名规则:
##   从 “/” 或者“空格”开始到 “.” “/” “空格” 结束，中间的一连串字符作为文件名，以.sh 作为文件扩展名
##   比如运行脚本后在 ps 中显示的进程如下
##   	root     11013     1  0 9月12 ?       00:04:54 java -jar /data/inspur/dispatch/bj-dispatch-2.1-SNAPSHOT.jar --spring.profiles.active=prod       
##   建议使用 bj-dispatch-2.1-SNAPSHOT.sh 作为启动脚本名。
##   不建议使用目录 inspur 或 dispatch 作为脚本名，如果目录下有其他程序运行，必然造成冲突。
