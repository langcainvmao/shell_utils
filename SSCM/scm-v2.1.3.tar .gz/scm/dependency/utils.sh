#!bin/bash
# 常用工具函数库

# 将字符全部转大写函数
## 一个参数
## $1 需要转换的字母
#####################
to_upper_case(){
  echo $1 | tr [:lower:] [:upper:]
}

# 字体颜色函数
## 需要一个参数
## 要使用指定颜色显示的文字以\n结束
## 示例 _red "success\n"
###################################
_red() {
  printf '\033[1;31;31m%b\033[0m' "$1"
}

_yellow() {
  printf '\033[1;31;33m%b\033[0m' "$1"
}

_green() {
  printf '\033[1;31;32m%b\033[0m' "$1"
}

# 数字判断函数
## 判断参数1，是不是数字，返回值大于 1 不是数字（0+0返回1）
## 需要使用一个参数
## 示例 is_number $num
##############################################
is_number(){
  expr $1 + 0 &>/dev/null
  return $?
}


# 功能描述函数
## 使用黄色字体显示制定的文件, 用于展示 readme 文件
## 需要使用一个参数
## $1 显示的文件地址
## 示例 discribe /root/readme.txt
################################################
describe(){
  local info=`cat $1`
  _yellow "$info\n" 
}


# 确认函数
## alert 有三个参数，第一个是提示语，第二和第三个参数用来匹配用户的输入（必须小写）
## 用户输入的等于第二个参数返回状态码为1， 输入的等于第三个参数返回 0
## 示例： alert "你确定吗？(yes/no)" "no" "yes"
##################################################################################
alert(){
  while :;do
    echo -en " \e[1;33m $1 \e[0m";read flag
    flag=`echo $flag | tr [:upper:] [:lower:]`
    if [ "$flag" == "$2" ];then
      return 1
    elif [ "$flag" == "$3" ];then
      return 0;
    else
      echo -e "\033[1;31m 输入有误，请重新输入 \033[0m"
    fi
  done
}



# 检查文件是否存在与指定的目录中
## 需要两个参数
## $1 目录
## $2 查找的文件
## 返回结果：找到了，则返回文件所在路径；没有找到则无返回
## 返回状态有三个 0 找到了， 1，没找到，2 $1 不是目录
#########################################################
check_file_in_dir(){
  # 存放要查询的路径
  #local DIR=$1
  # 存放目录列表
  local files=""
  # 存放目录中的目录和文件
  local fileOrDir=""
  # 判断 $1 是否是目录
  if [ ! -d $1 ]; then
    return 2
  fi
  # 判断文件在指定的目录是否存在,返回制定的目录，并正常退出
  if [ -f "${1}/${2}" ] || [ -f "${1}/.${2}" ]  ;then
    echo "${1}"
    return 0
  fi
  
  # 查看 DIR 目录中的内容,将文件添加到 files
  local files=$(ls -A $1 )

  # 判断 start_shells_list 是否为空,不空则检测对应的服务
  if [ "" == "$files" ]; then
    return 1
  else
    for fileOrDir in $files; do
      # 如果是目录则递归调用
      if [ -d ${1}/${fileOrDir} ];then
        check_file_in_dir "${1}/${fileOrDir}/" $2
        if [ $? == 0 ];then
          return 0
        fi
      fi
    done
  fi
  return 1
}


# 写日志函数
## 可以在外部定义变量 LOG_THRESHOLD, 或者 LOG_LEVEL 来控制写日志
### 日志级别可以设置成 0、1、2、3、4， （使用数字设置，大于5的数会取模5）
### LOG_THRESHOLD 可以设置成 0、1、2、3、4、5， 设置成 5 表示不打印 
## 有两个参数
## $1 写入 log 的内容
## $2 写入的 log 文件
## 示例 write_log "服务启动成功" ${log_dir}/start_stop.log
##########################################################
write_log(){
  local threshold=${LOG_THRESHOLD:-0}
  log_level=${LOG_LEVEL:-0}
  is_number $log_level
  if [ "$?" != "0" ];then
    log_level=0
  fi
  log_level=$(($log_level % 5))
  is_number $threshold
  if [ "$?" != "0" ];then
    threshold=0
  fi
  threshold=$(($threshold % 6))
  if [ $log_level -ge $threshold ];then
    echo "[`date +'%Y-%m-%d %H:%M:%S'`] $1" >> $2
  fi
  return
}

# 文件切割函数
## $1 要切割的文件
## 示例 cut_log $log_dir/check_result.log
#########################################
cut_file(){
  local time1=`date +'%Y%m%d%H%M%S'`
  mv $1 ${1%.*}_${time1}.bak
  /bin/bash -c " `ls -t ${1%.*}_*.bak| awk '5<NR{printf("rm -fr %s\n", $1)}'`"
}
