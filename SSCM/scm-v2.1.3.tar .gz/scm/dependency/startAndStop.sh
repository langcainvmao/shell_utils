#!bin/bash
## 启动、关闭相关的函数库


# 调用 start_shells_path 中的脚本启动程序
## 需要一个目录的路径作为参数,(路径作为参数传递可以实现递归)
## 示例：
## start_from_shell "./start_shells"
## start_from_shells函数并不判断服务名的唯一性。要通过 online 初始化时判断。
###########################################################################
start_from_shells(){
  local start_shells_path=$1
  local start_shell=""
  # 判断 start_shells_path 指定的目录是否存在
  [ -d "$start_shells_path" ] || mkdir -p $start_shells_path
  
  # 查看 start_shells_path 目录中的内容,将非隐藏的文件添加到 start_shell_list
  local start_shell_list=$(ls -A $start_shells_path | grep -v "^\.")

  # 用于存储启动的进程的 pid 
  local PID=""

  # 判断 start_shells_list 是否为空,不空则执行其中的脚本

  if [ "" == "$start_shell_list" ]; then
    return 0
  else
    for start_shell in $start_shell_list; do      
      if [ "$start_shell" == "" ];then
        return
      fi
      # 如果 start_shell 是目录就递归调用
        if [ -d ${start_shells_path}${start_shell} ];then
          start_from_shells "${start_shells_path}${start_shell}/"
        else
          # 如果服务已经运行就continue
          is_running ${start_shell%.sh}
          if [ $? == 0 ];then        
            continue
          fi
        # 如果没有执行权限，报错并记录日志
        if [ ! -x ${start_shells_path}${start_shell} ];then
          _red " $start_shell 启动脚本没有执行权限\n"
          write_log " $start_shell 启动脚本没有执行权限"  ${log_dir}/start_stop.log
          continue
        fi
        #在子进程中运行启动脚本
        {
          cd ${start_shells_path}
          ${start_shells_path}${start_shell} &
          write_pid ${start_shell%.sh} ${start_shell%.sh}
        }&
      fi
    done
  fi 
}


# 将服务的 pid 写到文件
## 使用二个参数
## $1 服务名
## $2 ps中搜索服务的关键字
## 示例 write_pid test.sh
####################################
write_pid(){
  sleep $wait_time
  PID=`get_pid "${2}"`
  # 如果 PID 不为空，记录 pid 到 PID 文件
  if [ "" != "$PID" ];then
    # 记录服务的 pid
    echo "$PID" > ${pid_files_path}${1}.pid
    # 记录日志
    write_log " $1 服务开始执行"  ${log_dir}/start_stop.log
    return
  fi
  # 只要启动失败，就清除 pid 文件
  rm -fr ${pid_files_path}${1}.pid
  write_log " $start_shell 服务未能正常执行"  ${log_dir}/start_stop.log
}


# 运行服务的启动脚本
## 脚本权限判断，运行脚本，写 pid 文件
## 用到 2 个参数
## $1 启动脚本脚本所在的目录
## $2 启动的脚本（不带sh）
## 示例 run_shell /scm/start_shells/ nifi.sh
############################################
run_shell(){
  is_running "$2"
  if [ $? == 0 ];then
    return 2
  fi
  if [ ! -x ${1}/${2}.sh ];then
    _red " ${1}/${2}.sh 启动脚本没有执行权限\n"
    write_log " ${1}/${2}.sh  启动脚本没有执行权限"  ${log_dir}/start_stop.log
    return 1
  fi
  #{   
   (   cd $1
      ${1}${2}.sh &
  )&      
  #  }&
  #write_pid "$2" "$2"
}


# 执行启动文件列表中的一行语句
## 使用一个参数
## $1 执行的语句
## 示例： run_line "jar1=/root/jar.sh -test"
############################################
run_line(){
  local tmp=$*
  local cmd=""
  local PID=""
  local service_name=""
  # 截取服务的cmd
  cmd="${tmp#*=}"
  # 判断服务是否运行
  is_running "$cmd"
  if [ $? == 0 ];then
    continue
  fi
  # 截取服务名
  service_name=`echo $tmp | cut -d'=' -f1`
  
  # 判断命令是否有执行权限
  local cmdWithoutParam=`echo $cmd | cut -d' ' -f1`
  if [ ! -x "${cmdWithoutParam}" ];then
    write_log " $cmd 启动脚本没有执行权限"  ${log_dir}/start_stop.log
    _red " $cmd 启动脚本没有执行权限"
    return 1
  fi
  # 执行服务命令
  {
  
   cd `dirname $cmdWithoutParam`
   $cmd &
  
  }&
  #write_pid "${service_name}" "${cmd}"
}



# 启动服务列表文件中的服务
## 用于启动服务的多实例
## 有一个参数
## $1 启动文件
## 示例 start_from_file start.txt
################################# 
start_from_file(){
  # 用与存储 pid
  local PID=""
  # 用于存储服务对应的命令
  local cmd=""
  local tmp=""

  # 从参数一提供的文件中按行读取数据
  while read -r line
  do
    # 读取非 # 开头的行
    tmp=`echo $line | grep -E "^[^#]"`
    [ "" == "$tmp" ] && continue  
    run_line "$tmp"
  done < $1
}



# 启动服务汇总
## 启动函数和脚本目录的服务
## 示例：start_services
## 因为启动服务后会启用检查（采用的是 case 穿透），所以启动不能有参数
#####################################################################
start_services(){
  # 判断主程序的 start 选项是否有参数
  if [ $1 ];then
    _red " start 选线不能有参数，如果想启动一个服务请使用 online 选项\n"
    exit 1
  fi
  
  # 启动服务列表文件中的程序
  start_from_file ${start_services_file}
  
  # 通过自定义脚本启动服务
  start_from_shells $start_shells_path

  # 因为采用的是case穿透；start之后直接check，所以在运行check之前在此处等一下子进程。（子进程判断程序是否启动的时候会等3秒）  
  sleep $wait_time
}


# 关闭所有服务
## 关闭所有的服务并删除 PID 文件
################################
stop_all(){
  # 如果选择 yes， 则关闭所有的服务
  alert "关闭所有服务，并删除 $pid_files_path目录下的所有文件(yes/no): "  "no" "yes"
  [ 0 -ne $? ] && return
  # 关闭监控
  stop_monitor
  # 判断是否存在 pid 文件
  ls ${pid_files_path}/*.pid >/dev/null 2>&1
  # 获取所有的 pid
  [ $? -ne 0 ] && return
  local pids=`cat ${pid_files_path}*.pid`
  # 如果 pid 不为空，则关闭服务
  if [ "" != "$pids" ] ; then
	for i in "$pids"; do
	  (
	    kill $i;
	    sleep $wait_time
	    local num=`ps -p $i | wc -l`
	    if [ $num -gt 1 ];then
	      kill -9 $i
	    fi
	  )&
	done
	wait
    rm -fr $pid_files_path/*.pid
  fi
  echo > $fail_service_list_file
}
