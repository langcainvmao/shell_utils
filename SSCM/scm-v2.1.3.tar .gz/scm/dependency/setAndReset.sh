#!bin/bash
## 软件环境配置

# 判断是否初始化过
## 返回非 0 表示已经初始化过
is_set(){
  local ret=`echo "$work_dir" | grep -c "^\./$"`
  return $ret
}

# 判断是否在主脚本所在的目录（初始化工作目录时使用）
#####################################################
isRunning_at_right_dir(){
  { (ls | grep $0) || (ls |grep ${0:2})||(echo $0 | grep -qE "^/") } >/dev/null 2>&1
  if [ $? -ne 0 ] ;then
    echo -e "\e[1;031m 请到本脚本所在目录运行 init 命令\e[0m"
  exit 1
  fi  
}

# 初始化工作目录
## 会修改主程序里面的 work_dir 变量
###################################
init_workdir(){
  isRunning_at_right_dir
  is_set
  if [ $? -eq 0 ];then
    _red " 已经初始化过，请先reset\n"
    exit 2
  fi
  local workDir=`pwd`$(echo $workDir | sed "s#\/#\\\\/#g")
  local T=$(echo $workDir | sed "s#\/#\\\\/#g")
  sed  -i  's#^work_dir=\".*\"#work_dir=\"'${T}\/'\"#' $0
  _green " 工作目录初始化完成"
}

# 设置 Java 环境变量
## 需要一个参数
## $1 全局变量文件的路径
##############################
set_JAVA_HOME(){
  alert "本脚本使用的 \e[0m\e[1;31mJAVA_HOME=$JAVA_HOME \e[0m \e[1;33m是否正确（yes/no）:" "yes" "no"
  [ 0 != $? ] && return
  while :; do
    echo -en "\e[1;33m 请输入正确的JAVA_HOME: \e[0m";read JAVA_HOME
    local a=$(echo $JAVA_HOME | sed   "s#\/#\\\\/#g")
    sed  -E -i  's/(^export JAVA_HOME=).*/\1\"'${a}'\"/' $1 > /dev/null 2>&1
    if [[ $? -ne 0 ]];then
      _red " 输入的路径有问题，请重新输入"
    else
      _green " JAVA_HOME 配置完成\n"
      break
    fi
  done
}

# 添加开机自启动函数 (已停用)
# 注意：已停用，改用systemd的方式实现开机自启。add2systemd
#####################################################
add2startup(){
  # 判断是否已经添加到开机自启动脚本
  local cmd=`echo $0 | grep -o  "[^/]*$"`
  cmd="`pwd`/$cmd"
  grep -q "$cmd" /etc/rc.local
  if [ 0 != $? ];then
    # 询问是否添加开机启动
    alert "是否将本脚本添加到开机自启动（yes/no)：" "no" "yes"
    [ 0 != $? ] && return
    echo -e "########## 进程启动和检测脚本 #########" >> /etc/rc.local
    echo  "/bin/bash $cmd monitor" >> /etc/rc.local
    echo "#######################################" >> /etc/rc.local
    chmod u+x /etc/rc.d/rc.local
  fi
  _green " 已添加本脚本至开机启动文件 /etc/rc.local\n"
}

# 添加到 systemd 启动
add2systemd(){
  alert "是否将 scm 服务添加到开机启动项(yes/no)" "no" "yes" 
  [ 1 == $? ] && return
  create_systemd_file
  systemctl daemon-reload
  systemctl enable scm.service
  _green " 已添加到开机启动项\n"
}

# 从 systemd 中删除
del_from_systemd(){
  systemctl disable scm.service
  if [ -f /usr/lib/systemd/system/scm.service ];then 
      rm -fr /usr/lib/systemd/system/scm.service
  fi
  systemctl daemon-reload
  _green " 已取消开机启动\n"
}

# 添加 utils 到 path 路径
add2path() {
  echo "########## 添加scm的utils到path目录##########">> /etc/profile
  echo "PATH=\$PATH:`pwd`/utils/" >> /etc/profile
  echo "#############################################" >>/etc/profile
  _green " utils目录已添加到 PATH 变量\n"
}


#################  初始化 ###################
init(){
  if [ -f /usr/lib/systemd/system/scm.service ];then
    _red " scm 已经安装过，请先将原来的 scm 工具 reset \n"
    exit 1
  fi
  
  # 设置变量脚本中，主脚本所在路径
  init_workdir $0

  # 创建 start_shells_path 指定的目录
  [ -d "$start_shells_path" ] || mkdir -p $start_shells_path
  [ -d "$check_shells_path" ] || mkdir -p $check_shells_path
  [ -d "$pid_files_path" ] || mkdir -p $pid_files_path
  [ -d "$log_dir" ] || mkdir -p $log_dir
  _green " $start_shells_path $check_shells_path $pid_files_path $log_dir 脚本目录已创建\n"

  # 创建自定义检测脚本demo
  create_checkdemo

  # 创建链接生成辅助程序
  #create_createLink
  
  # 添加到开机自启动
  #add2startup
  add2systemd
  
  # 添加 utils 到环境变量
  add2path

  # 创建别名  
  create_alias
  
  # 创建工具文件
  create_scmutils

  # 启用log
  enable_log

  # 设置 Java 环境变量
  #set_JAVA_HOME "$conf_file"

  # 让父shell重新加载
  #_red " 初始化工作已经完成,稍后将断开连接，使环境变量生效。请重新连接\n"
  #read -p " 按任意键继续"
  #kill -HUP $PPID
  echo -e "\033[47;31m init 工作已经完成,请断开连接重新登陆，使环境变量生效 \033[0m"
}



# 还原函数
## 依赖全局变量 start_shells_path 、 check_shells_path、$conf_file 和 log_name
## 依赖工具函数库，日志函库
######################################################
reset_config(){  
  # 删除创建的目录
  local conf_dir=`echo $services_list_file | grep -o ".*/"`
  alert "是否要删除 $start_shells_path  $check_shells_path(yes/no): "  "no" "yes"
  if [ 0 = $? ] ; then
    rm -rf $start_shells_path $check_shells_path 
    _green " ${start_shells_path} 和 ${check_shells_path} 目录已删除\n"
  fi
  
  # 关闭所有的服务并删除 PID 文件
  stop_all

  # 关闭日志功能
  disable_log
  
  # 从rc.local 中删除启动项
  #sed -i '/########## 进程启动和检测脚本/,/#############################/d' /etc/rc.local
  del_from_systemd
    #_green " 开机启动项已删除\n"
  
  # 删除日志文件
  alert "是否要删除日志目录及日志文件(yes/no)" "no" "yes"
  if [ 0 = $? ] ; then
    rm -fr $log_dir
    _green " $log_dir 目录已删除\n"
  fi
  
  # 恢复 work_dir 默认值
  sed  -i  's#^work_dir=\".*\"#work_dir=\"\.\/\"#' $0
  _green " 工作目录配置已清除\n"
  

  # 删除别名
  if [ -f /etc/profile.d/scm.sh ];then
    rm -fr /etc/profile.d/scm.sh
  fi
  _green " 别名已删除\n"
  
  # 删除工具文件
  if [ -f /etc/profile.d/scmutils.sh ];then
    rm -fr /etc/profile.d/scmutils.sh
  fi
  _green " 工具文件已删除\n"

  # 删除环境变量
  sed -i '/########## 添加scm的utils到path目录/,/#############################/d' /etc/profile
  _green " utils 目录已从环境变量删除\n"

  # 让父shell重新加载
        #_red " reset工作已经完成,稍后将断开连接，使环境变量生效。请重新连接\n"
        #read -p " 按任意键继续"
        #kill -HUP $PPID
    echo -e "\033[47;31m reset 工作已经完成,请断开连接重新登陆，使环境变量生效\033[0m"
}
