#!/bin/bash
# 单个服务上下线


# 判断online或者offline是否有参数传递
## 有两个参数
## $1 online 或者 offline
## $2 判断的参数
## 示例 has_param online $1   此处的$1是调用 has_param 函数的父函数的$1
#######################################################################
maintain_has_param(){
  if [ -z $2 ];then
    if [ "$1" == "online" ];then
      _red " 请在 $1 选项后输入需要恢复上线的的服务\n" 
    else
      _red " 请在 $1 选项后输入需要下线维护的的服务\n"
    fi
    exit 1
  fi
}


# 检查服务的上线状态
## 会被 maintain_start_servie 调用
## 使用一个参数
## $1 要检测的服务名
## $2 ps中搜索服务的关键字
## 示例 is_online_ok "dipatch" "bj-dispatch-1.1"
###########################################################
is_online_ok(){
  local PID
  # 有些jar 程序启动很慢，所以需要等一下
  sleep  $wait_time
  # 检查要上线的服务运行了多少个进程
  PID=`get_pid "$2"`
  local num=`echo "$PID" | wc -l`
  # 如果有一个进程运行，证明上线成功
  if [ $num -eq 1 ]; then
    #write_pid "$1" "$2" 
    echo "$PID" > ${pid_files_path}${1}.pid
    _green "$1 开始运行\n"
    write_log " $1 上线成功"  ${log_dir}/start_stop.log
    return 0
  # 如果检测到多个服务的进程，有可能是在启动进程的过程中使用其他方式启动了另外的服务进程
  elif [ $num -gt 1 ];then
    _red "检测到了多个 $1 服务， 可能有其他方式或程序启动了 $1 服务，请手动将 $1 服务的正确 pid 写到 ${pid_files_path}/$1.pid\n"
    return 1
  # 如果没有检测到服务进程，可能是服务名使用 ps 搜索不到; 或者程序启动失败
  elif  [ $num -eq 0 ];then
    _red "没有搜索到脚本 $1 对应的服务，$1 上线失败，请检查脚本；如果程序已运行，请修改启动脚本名\n
        请使用   ps -ef | grep '服务名'    测试\n"
    write_log " $1 上线失败"   ${log_dir}/start_stop.log
  return 2
  fi
}


# 启动（某个）服务
## 需要一个参数
## $1 启动的服务名
## 示例 maintain_start_service nginx
#####################################
maintain_start_service(){
  # 用户存储启动命令
  local service_cmd=""
  # 如果服务名对应的启动脚本存在于 ${start_shells_path} 目录中，则给 DIR 赋值
  local DIR=`check_file_in_dir ${start_shells_path} ${1}.sh`
  # 如果启动文件存在
  if [ "" != "${DIR}" ]; then
    # 去除服务对应的启动文件的隐藏模式
    mv ${DIR}/.$1.sh ${DIR}/$1.sh 2>/dev/null
    is_running $1
    # 如果已经运行，则直接退出 
    if [ $? -eq 0 ] ; then
      _yellow " 检测到 $1 已在运行中。\n \
      start_shells 方式不支持多实例，要想启动服务多实例请联系管理员，通过编辑服务列表文件 $services_list_file 的方式实现\n\
      如果是首次上线，请使用 utils/is_running.sh  脚本排查，是否在 ps 命令显示的结果中，出现了使用该关键字的其他进程。\n\
      或者联系管理员，尝试通过配置启动文件列表的方式运行"
      exit
    fi
    # 如果服务没有运行，则运行启动脚本
    run_shell "$DIR"   "${1}"
    # 检测启动是否成功
    is_online_ok "${1}" "${1}"
    [ "$?" == "0" ] && return 0
    return 1
  fi
  # 如果不存在于 ${start_shells_path} 目录中，在检查是否在服务启动列表文件中
  service_cmd=`grep -E "^#?$1=" ${start_services_file}`
  # 如果服务启动文件中也没有，则告知用户服务不存在，并退出
  if [ "" == "$service_cmd" ]; then
    _red "输入的服务 $1 不存在\n"
    return 1
  fi
  # 修改启动文件列表中的状态
  sed -i -r 's/^#'$1'=/'${1}='/' ${start_services_file}
  # 运行启动文件服务列表中的服务
  run_line "${service_cmd#\#}"
  is_online_ok "$1" "${service_cmd#*=}" 
  [ "$?" == "0" ] && return 0
  return 1
}


# 服务上线
## 需要一个参数
## $1 恢复的服务名
## 示例 online nginx
#####################
online(){
  # 检查是否传递了参数
  maintain_has_param online $1
  # 尝试上线服务，并检测
  maintain_start_service "$1"
} 


# 服务下线
## 需要一个参数
## $1 准备下线的服务名
## 示例 offline nginx
########################
offline(){
  local service_name=""
  local PID
  local cmd=""
  local DIR=""
  
  # 判断是否传参进来
  maintain_has_param offline $1
  # 检查服务对应的脚本是否存在，存在则给 DIR 赋值
  DIR=`check_file_in_dir ${start_shells_path} ${1}.sh`  
  # 如果服务对应的脚本存在
  if [ "" != "${DIR}" ]; then
    # 将服务对应的启动文件转换成隐藏模式
    mv ${DIR}/$1.sh ${DIR}/.$1.sh 
    kill_process "$1" "$1"
    # 通过 kill_process 的返回值，判断服务下线的情况
    if [ $? == 0 ];then
      return 0
    elif  [ $? == 1 ];then
      return 1
    fi
  fi
  # 如果启动脚本不存在，则检查服务启动列表文件中是否存在
  service_name=`grep -E "#?$1=" ${start_services_file}`
  # 如果启动文件也不存在，则提示错误并退出
  if [ "" == "$service_name" ]; then
    _red "输入的服务 $1 不存在\n"
    return 1
  fi 
  # 如果存在， 则修改启动文件
  sed -i 's/^'$1='/#'${1}='/' ${start_services_file}
  cmd=`awk -F"=" '/'${1}='/{print $2}' ${start_services_file}`
  # 关闭服务
  kill_process "$1" "$cmd"
}


# 关闭（单个）服务
## 需要两个参数
## $1 要关闭的服务名
## $2 在 ps 中搜索服务的关键字
## 有返回状态码， 0 是成功， 1 是该服务未运行，2 是关闭过程中发现了其他实例
## 示例 kill_process nginx
############################################################################
kill_process(){
  local PID
  # 如果要关闭的服务的 pid 文件存在，则关闭对应的服务实例
  if [ -f "${pid_files_path}/$1.pid" ];then
    PID=`cat ${pid_files_path}/$1.pid`
    # 如果 pid 文件不为空
    if [ "$PID" != "" ];then
      kill  $PID > /dev/null 2>&1
      sleep 1
      # 如果正常关闭不了，就使用 kill -9 强杀
      local n=`ps -p $PID | wc -l`
      [[ $n -eq 2 ]] && kill -9 $PID        
    fi
    # 不管PID文件是否为空，一律删除服务对应的 PID 文件
    rm -fr ${pid_files_path}/$1.pid
  fi
  # 检查要下线的服务是否已经关闭
  is_running "$2"
  # 如果找到了该服务的其他实例，则通知用户。（不要轻易关闭其他实例）
  if [ $? == 0 ];then
    # 提示 "您可能通过非 SCM 的管理方式启动了 $1 服务，请手动关闭"  
    _red " 您可能通过其他方式启动过 $1 服务，请手动关闭 $1 服务"
    write_log " 您可能通过其他方式启动过 $1 服务，请手动关闭 $1 服务" ${log_dir}/start_stop.log   
    return 1
  # 如果没有找到，则提示下线成功
  else
    # _green "$1 服务已经成功下线\n"
    _green " $1 下线成功\n" 
    write_log " $1 下线成功"  ${log_dir}/start_stop.log
    return 0
  fi
}
