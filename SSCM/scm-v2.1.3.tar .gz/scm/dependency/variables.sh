#!bin/bash
## 设置变量的文件

## 这两个数组存放服务检查结果的详细信息
declare -A fail_services_array
declare -A success_services_array

## 设置java环境变量
#export JAVA_HOME=""
#export PATH=$JAVA_HOME/bin:$PATH

## 是否写日志,no 关闭日志功能 yes 启动日志功能
LOG_THRESHOLD=0

## log 文件名
log_dir="${work_dir}/logs/"
check_log_name="${log_dir}check_result.log"

## 包含启动脚本的目录
start_shells_path="${work_dir}/start_shells/"

## 包含检测脚本的目录
check_shells_path="${work_dir}/check_shells/"

## 启动服务列表文件
start_services_file="${work_dir}/startServices.list"

## 配置文件路径（就是本文件的路径）
conf_file="${work_dir}/dependency/variables.sh"

## 监控到的有问题的服务列表
fail_services=""

## 监控与重启服务子进程之间通信的文件
fail_service_list_file="${log_dir}/fail_services"

## PID 文件存放的位置
pid_files_path="${work_dir}/PID/"

## 依赖库文件所在目录
dependency_path="${work_dir}/dependency/"

## 重启服务间隔时间的基数(秒)
interval_seconde=20

## 运行一轮重启服务，每次重启服务的间隔倍数
restart_interval_time="1 2 3 3"

## 超过多少行，就进行日志切割
log_max_line=100000

## 检查程序是否运行前的等待时间（有些脚本需要检查端口等操作，所以设置了等待时间）
wait_time=15

## 监控检查的间隔时间(秒）
check_interval_time=60
