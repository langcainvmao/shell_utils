#!bin/bash
# 监控相关的函数
## 本库函数依赖 utils 函数库

# 启动监控函数
## 依赖 utils 和 checkServices 函数库
## 使用了全局变量 start_shells_path
## 需要传递程序名作为参数
## 示例
## monitor $0
monitor() {
  # 用来接收check返回的错误列表
  local fail_services=""
  # 用来保存监控轮询的间隔时间
  #local time2=""
  
  # 判断是否有监控进程在运行
  if [ -f ${pid_files_path}/monitor.pid ];then
    # 获取监控进程的 pid
    local PID=`cat ${pid_files_path}/monitor.pid`
    # 如果 pid 为空，就删除 PID 文件
    [ "" == "$PID" ] && rm -fr ${pid_files_path}/monitor.pid
    # 通过 pid 查看监控是否运行
    local n=`ps -p $PID |wc -l`
    if [ $n == 2 ];then
      _yellow "监控进程已在运行中\n"
      exit
    fi
  fi
  
  # 创建一个子进程后台监控
  {
    # 程序级别的开启日志功能
    LOG_THRESHOLD="0"    
    # 记录检查多少次后判断一下日志文件是否需要切割
    local times=100
    # 记录次数
    local n=0   
    # 记录子shell的pid （用来重启服务的子进程的 pid）
    local sub_pid="" 
    # 子shell是否运行
    local sub_shell_isRuning=0
    _green "监控进程开始运行\n"
    
    while : ; do
      # 检测进程
      check_services_for_monitor     
      # 如果错误列表不为空，则调用 try_restart 函数
      if [ "" != "$fail_services" ] && [ ! -f ${pid_files_path}/tryRestart.pid ] ;then
        try_restart
      fi
      # 重新初始化 fail_services 变量
      fail_services=""
      # 记录次数并判断是否切割日志文件
      ((n++))
      #if [ $n -gt $times ]; then
      if [ $n -gt 5 ]; then
        n=0
        {
          for i in `ls ${log_dir}/*.log`;do
            local lines=`wc -l "$i" | cut -d' ' -f1`
            #if [ $line -gt $log_max_line  ];then
            if [ $lines -gt $log_max_line ];then
              cut_log "$i"
            fi
          done
        }&
      fi
      sleep $check_interval_time
    done
  }&
  
  # 将监控进程的 pid 保存到 PID 文件中
  echo $! >  ${pid_files_path}/monitor.pid
}


# 检查服务重启服务结果
## 使用两个参数
## $1 服务名
## $2 ps 中搜索服务的关键字
## 示例 is_restart_ok "jar"  "test/jar1.sh"
##################################3
is_restart_ok() {
  sleep $wait_time
  #is_running "${2}"
  local PID=`get_pid $2`
  #if [ $? -eq 0 ];then
  if [ "" != "$PID" ] ;then
    # 如果重启成功则创建服务的PID文件
    #pid_num=`echo $PID | wc -l`
    #if [ $pid_num -gt 1 ];then
    #sleep 1; PID=`get_pid $2`;
    #fi
    echo "$PID" > ${pid_files_path}${1}.pid

    # 同时删除错误文件中的该记录
    sed -i 's/ '${1}'\b//g' $fail_service_list_file
    write_log " 重启 $1 服务成功"  ${log_dir}/start_stop.log
        ${work_dir}/utils/alarm.sh "[`date +'%Y-%m-%d %H:%M:%S'`]" "重启成功" "$1" &
    return 0
  else
    write_log " 重启失败，稍等 $interval_time 秒将再次尝试重启 $1 服务"  ${log_dir}/start_stop.log
    return 1
  fi
}


# 尝试重启服务列表函数
## 使用全局变量 $log_dir 和 fail_service_list_file
## 本函数依赖检测函数库的 is_runing 函数
###################################################
try_restart(){
  local service
  local fail_services=""
  local DIR=""
  local service_line=""
  local keyWord=""
  local no_blank
  local try_restart_log_file=$log_dir/start_stop.log
  #[ -z "$services_list_file" ] && return
  {
    for i in ${restart_interval_time}; do
      interval_time=`expr $interval_seconde \* $i`;
      # 获取未正常运行的服务列表
      fail_services=`cat $fail_service_list_file`
      write_log " 检测到服务${fail_services} 未正常执行，尝试重启服务"   ${log_dir}/check_result.log
      ${work_dir}utils/alarm.sh "[`date +'%Y-%m-%d %H:%M:%S'`]" "未正常执行" ${fail_services} & 
      for service in ${fail_services};do
        {
          # 检查 service 启动脚本所在的准确目录
          DIR=`check_file_in_dir "${start_shells_path}" "${service}.sh"`
          # 如果存在于目录中，则运行脚本
          if [ "" != "${DIR}" ]; then
            run_shell "$DIR" "$service"                
            keyWord="${service}"
          else
            service_line=`grep -E "^${service}=" ${start_services_file}`
            # 如果服务启动文件中也没有，则告知用户服务不存在，并continue
            if [ "" == "$service_line" ]; then
              write_log "发现 $service 服务非正常下线维护，启动脚本已不存在,或在启动服务列表文件中已清除" $try_restart_log_file
              sed -i 's/ '${service}'\b//g' $fail_service_list_file
              continue
            fi
            run_line "${service_line}"
            keyWord="${service_line#*=}"
          fi
          is_restart_ok "$service" "$keyWord"
        }&
      done
      wait
      # 每轮尝试重启之后，判断记录未正常运行服务的文件是否为空
      no_blank=`cat $fail_service_list_file |sed -r "s/[[:blank:]]//g"` 
      if [ "" ==  "$no_blank" ]; then
        rm -fr ${pid_files_path}tryRestart.pid
        exit 0
      fi
      sleep $interval_time
    done
    # 经过一组尝试重启后，如果是有没有正常运行的服务，则删除重启服务的pid，等待系统创建新的重启服务子进程
    rm -fr ${pid_files_path}tryRestart.pid
  }&
  # 记录恢复进程的 PID
  echo "$!" > ${pid_files_path}tryRestart.pid
}

# 关闭监控函数
## 依赖 utils 和 checkServices 函数库
## 示例 stop_monitor
########################################
stop_monitor() {
  # 如果有重启服务子进程运行，也关闭掉
  if [ -f ${pid_files_path}/tryRestart.pid ]; then
    kill -9 `cat ${pid_files_path}/tryRestart.pid`
    rm -fr ${pid_files_path}/tryRestart.pid
  fi
  # 如果监控进程文件不存在则退出
  if [ ! -f ${pid_files_path}/monitor.pid ]; then
    _yellow " 监视进程没有执行\n"
    return
  fi
  local PID=`cat ${pid_files_path}/monitor.pid`
  #if [ -z $PID ]&& [ "" == "$PID" ]; then  
  if [ "" == "$PID" ]; then  
    _yellow " 监视进程没有执行\n"
    return
  fi
  #kill -9 $(ps aux | grep "$cmd monitor" | grep -v "grep" | awk '{print $2}')
  kill $PID
  rm -fr ${pid_files_path}/monitor.pid
  echo > $fail_service_list_file    
}



