#!bin/bash
# 检测相关的函数

# 检查服务的运行状态
## 通过比较 pid 文件中的值，与 ps 匹配到的值判断服务的运行状态
## 使用两个个参数
## $1 服务名
## $2 ps 搜索该服务的关键字
## 检测结果会写入日志；写入失败列表（供监控monitor进程调用）； 写入成功或失败数组（供show_check_result消费）
## 返回状态有 6 种；
### 0 进程正在运行
### 1 服务实例被正常关闭了
### 2 服务实例是使用其他方式启动的
### 3 服务实例被使用其他的方式或非正常关闭了(非 SCM 管理方式下线)
### 4 服务实例被使用其他的方式或非正常关闭了,又被使用其他的方式启动了（非 SCM 管理方式）
### 5 服务运行着多实例，SCM 管理不支持启动参数相同的多实例，请联系管理员
## 示例 inspect_service dispatch "dispatch"
###########################################################################################################
inspect_service(){
  local service_name=$1
  local PID=""
  local ps_PID=""
  local num=""
  # 通过读取 pid 文件的方式获得服务的 pid
  # 如果服务对应的 pid 文件存在, 则读取文件中的 pid
  if [ -f $pid_files_path/${service_name}.pid ];then
    PID=`cat $pid_files_path/${service_name}.pid`
  fi 
  # 通过 ps 匹配服务的方式获取服务的 pid
  ps_PID=`get_pid "$2"`
  # 如果检测到运行着多实例，提示错误
  num=`echo $ps_PID | awk '{print NF}'`
  if [ $num -gt 1 ];then
    write_log " $1 服务运行着多实例，SCM 管理不支持启动参数相同的多实例，请联系管理员！！！\n" ${log_dir}/check_result.log
    fail_services_array[$service_name]="multi-instance"
    return 5
  fi
  # 如果pid文件中的 pid 与 ps 匹配到的 pid 一致，认为程序运行正常
  if [ "${PID}" == "${ps_PID}" ] && [ "$PID" != "" ];then
    write_log " $service_name 进程正在运行" ${log_dir}/check_result.log
    success_services_array[$service_name]="success"; 
    return 0
  # 如果pid文件不存在同时也没有指定服务在运行，则认为程序被关闭了
  elif [ "${PID}" == "${ps_PID}" ] && [ "${ps_PID}" == "" ];then
    write_log " $service_name 服务实例没有运行" ${log_dir}/check_result.log
    fail_services_array[$service_name]="fail"
    fail_services="$fail_services $service_name"
    return 1
  # 如果 pid 文件不存在，ps 中又匹配到该服务，则认为该服务是使用非 SCM 管理的方式启动的
  elif [ "" == "${PID}" ];then
    if [ -f ${pid_files_path}/tryRestart.pid ]; then
      write_log " $service_name 进程正在运行" ${log_dir}/check_result.log
      success_services_array[$service_name]="success";
      return 0
    fi
    write_log " $service_name 服务实例正在运行，是使用其他方式启动的(非scm管理的方式)" ${log_dir}/check_result.log
    success_services_array["$service_name"]="startByOther"
    return 2
  # 如果 pid 文件有内容，但是 ps 没有匹配到该服务，则认为该服务被使用非 SCM 管理的方式关闭了
  elif [ "" == "${ps_PID}" ];then
    write_log " $service_name 服务实例非正常关闭了,或非 SCM 管理方式下线了" ${log_dir}/check_result.log
    fail_services_array["$service_name"]="closeByOther"
    fail_services="$fail_services $service_name"
    return 3
  # 如果 pid 文件的内容与 ps 匹配到的服务进程号不符，则认为服务非正常关闭了，又被使用非 SCM 管理的方式启动了  
  elif [ ${PID} != ${ps_PID} ];then
    if [ -f ${pid_files_path}/tryRestart.pid ]; then
      write_log " $service_name 服务实例非正常关闭,现已启动" ${log_dir}/check_result.log
      success_services_array[$service_name]="success";
      return 0
    fi
    write_log " $service_name 服务实例非正常关闭,又被使用其他的方式启动了（非 SCM 管理方式）" ${log_dir}/check_result.log
    success_services_array["$service_name"]="startByOther"
    return 4
  fi
}


# 检查服务启动文件中的服务
## 使用了全局变量 fail_services 传递数据
## 使用一个参数
## $1 服务启动文件名
## 示例 check_from_file ${work_dir}/dependency/startServices.list
#################################################################
check_from_file(){
  while read -r line
  do
    local service_name=""
    local tmp=""
    local cmd=""
    # 读取非 # 开头的行
    tmp=`echo $line | grep -E "^[^#]"`
    [ "" == "$tmp" ] && continue
    # 截取服务的cmd
    cmd=${tmp#*=}
    # 截取服务名
    service_name=`echo $tmp | cut -d'=' -f1`
    # 检查服务运行状态
    inspect_service "$service_name" "$cmd"
  done < $1
}

# 传递一个参数，判断该参数同名的进程是否运行
## 如果运行结果大于 0 ，表示该进程未正常运行
## 示例
## is_running nginx
###############################################
is_running(){
  local temp=""
  local ret=""
  local cmd=""
  #local ret=`ps -ef | grep -E "\b[[:space:]]*${*}[[:space:]]*\b" | grep -v grep | grep -v $0 | wc -l`
  echo $1 | grep -q "/"
  # 如果参数中带有“/”,则直接判断
  if [ $? == 0 ]; then
	ret=`ps -ef | grep -E "\s+${*}\b" | grep -v "grep" | grep -v "$0" | wc -l`
    [ $ret -gt 0 ] && return 0 || return 127 
  fi
  # 如果传进来的参数中不包含“/”,则判断在 startServices.list 中是否有冲突项
  temp=`grep "$1" ${start_services_file}` 
  # 如果有冲突项
  if [ "" != "$temp" ];then
    cmd="${temp#*=}"
    ret=`ps -ef | grep -e "[/ ]${*}[./ ]" -e "[/ ]${*}$" | grep -v "grep" | grep -v "$0" |grep -v "$cmd"| wc -l`
  else
    # 如果在 startServices.list 中没有冲突项目
    ret=`ps -ef | grep -e "[/ ]${*}[./ ]" -e "[/ ]${*}$" | grep -v "grep" | grep -v "$0" | wc -l`
  fi
  [ $ret -gt 0 ] && return 0 || return 127 
}

# 获取pid
## 用到一个参数
## $1 搜索的服务关键字
## 示例 get_pid  nginx
########################
get_pid(){
  local temp=""
  local cmd=""
  
  echo $1 | grep -q "/"
  if [ $? == 0 ]; then
    ps -ef | grep -E  "\s+${*}\b" | grep -v "grep" | awk '$3==1{print $2}'
    return 
  fi
  temp=`grep $1 ${start_services_file}` 
  # 如果在 startServices.list 中存在冲突项
  if [ "" != "$temp" ];then
    cmd=${temp#*=}
    ps -ef | grep -e "[/ ]${*}[./ ]" -e "[/ ]${*}$" | grep -v "grep" | grep -v "$0" |grep -v "$cmd"| awk '$3==1{print $2}'
    return
  else
  # 如果在 startServices.list 中没有冲突项目
    ps -ef | grep -e "[/ ]${*}[./ ]" -e "[/ ]${*}$"| grep -v "grep" | grep -v "$0" | awk '$3==1{print $2}'
  fi
}

# 展示检查结果
## 依赖全局变量 success_services_array,fail_service_arry 和 fail_service_list_file
## 依赖 util 工具函数库
## 返回状态 0 所有服务都在正常运行， 非零表示没有正常运行的服务的数量
##################################################################################
show_check_result(){
  local flag=0
  local ser=""
  local status=""
  for ser in ${!success_services_array[@]};do
    status=${success_services_array[$ser]}
    if [ "success" == "$status" ]; then
      _green " 检测到 $ser 进程正在运行\n"     
    elif [ "startByOther" == "$status" ]; then
      _green " 检测到 $ser 服务实例正在运行，是使用其他方式启动的(非scm管理的方式)\n"
    fi
    success_services_array[$ser]=""
  done
  for ser in ${!fail_services_array[@]};do
    status=${fail_services_array[$ser]}
    if [ "fail" == "$status" ]; then
      _red " $ser 未正常运行\n"
      ((flag++))
    elif [ "closeByOther" == "$status" ]; then
      _red " 检测到 $ser 服务实例非正常关闭了，或被使用非 SCM 管理的方式关闭了\n"
      ((flag++))
    elif [ "multi-instance" == "$status" ];then
      _red " $ser 服务运行着多实例，SCM 管理不支持启动参数相同的多实例，请联系管理员！！！\n"
    fi
    fail_services_array[$ser]=""
  done
  return $flag
}


# 调用制定目录中的脚本检测函数
## 调用制定目录中的脚本检测，结果记录到 services_array 数组
## 需要一个参数
## $1 自定义检测程序存放的目录
## 示例 
## check_with_custom_scripts "./check_shells"
##############################################################
check_with_custom_scripts(){
  local check_shells_path=$1
  # 判断 start_shells_path 指定的目录是否存在
  [ -d "$check_shells_path" ] || mkdir -p $check_shells_path
  
  # 查看 start_shells_path 目录中非隐藏的内容
  local check_shell_list=$(ls -A $check_shells_path | grep -E "^[^.]*.sh$")

  # 判断 start_shells_path 中是否有非隐藏文件,不空则运行其中的脚本
  if [ -z "$check_shell_list" ]; then
    return
  else
    echo > ${check_shells_path}/custom_check_success
    echo > ${check_shells_path}/custom_check_fail
    for check_shell in $check_shell_list; do
      {
        cd $check_shells_path
        if [ ! -x ${check_shell} ];then
          _red " ${check_shell} 检测程序没有执行权限\n"
          write_log " ${check_shell} 检测程序没有执行权限" ${log_dir}/check_result.log
          exit 1
        fi
        ${check_shells_path}/${check_shell} &
      }&
    done
    sleep $wait_time
    local f_services=`cat ${check_shells_path}/custom_check_fail`
    local s_services=`cat ${check_shells_path}/custom_check_success`
    for service in $s_services;do
      write_log " $service 进程正在运行" ${log_dir}/check_result.log
      success_services_array[$service]="success"
    done
    for service in $f_services;do
      write_log " $service 服务实例运行异常,或非 SCM 管理方式下线了" ${log_dir}/check_result.log
      fail_services_array[$service]="fail"
      fail_services="$fail_services $service"    
    done
  fi
}


# 检测启动脚本目录中的脚本是否运行
## 使用了全局变量 fail_services 传递数据
## 需要一个目录的路径作为参数
## 返回值是一个错误列表
## 示例：
## check_services_in_startShells 
###########################################
check_services_in_startShells(){
  local start_shells_path=$1
  local service=""
  # 判断 start_shells_path 指定的目录是否存在
  [ -d "$start_shells_path" ] || return 0 
  # 查看 start_shells_path 目录中的内容,将非隐藏的文件添加到 start_shell_list
  local start_shell_list=$(ls -A $start_shells_path | grep -v "^\.")  
  # 判断 start_shells_list 是否为空,不空则检测对应的服务
  if [ -z "$start_shell_list" ]; then
    return
  else
    for service_name in $start_shell_list; do
      # 如果是目录则递归调用
            service_name=${service_name%.sh}
      if [ -d ${start_shells_path}${service_name} ];then
        check_services_in_startShells "${start_shells_path}${service_name}/"
      else
        inspect_service "$service_name" "$service_name"
      fi
    done
  fi
}


# 为 monitor 组合的监控项
## 有一个返回值
#################################
check_services_for_monitor(){
  local fail_service_list_file=${log_dir}/fail_services
  check_services_in_startShells $start_shells_path
  check_with_custom_scripts $check_shells_path
  check_from_file ${start_services_file}
  echo "$fail_services" > $fail_service_list_file
}


# 通用检测程序
## 检测列表中的服务是否运行，没有过滤条件没有 is_running 那么苛刻
## 需要至少一个参数
## 示例 checkServices_check_services nginx redis
###########################################################3
checkServices_common_check_services(){
  local progresses
  for i in $@; do
    progresses=$(ps -ef | grep $i | grep -v grep| grep -v $0)
    if [ -n "$progresses" ] || [ "" != "$progresses" ]; then
      _green "找到了 $i 进程\n"
      _green "$progresses\n\n"
      progresses=""
    else
      _red "$i 进程没有运行\n\n"
      progresses=""
    fi
  done
  return
}


############ 检查服务汇总 ############
# 可以使用 # 井号注释掉不需要检测的进程
check_services(){
  if [ "" != "$1" ]; then
    checkServices_common_check_services $*
    return
  fi
  
  #检测自定义脚本启动的程序是否正常
  check_services_in_startShells ${start_shells_path}

  # 调用自定义检测脚本
  check_with_custom_scripts $check_shells_path
  
  # 检测服务列表文件中的程序
  check_from_file ${start_services_file}
  
  # 显示检测结果
  show_check_result
}

