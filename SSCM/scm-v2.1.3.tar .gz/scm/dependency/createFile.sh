#!/bin/bash
## 在制定的目录下生成脚本或文件
## 本函数库依赖工具函数库

# 创建链接生成辅助程序
## 需要使用全局变量 start_shells_path
########################################
create_createLink(){
  # 检查 createLink 脚本是否存在
  local createScript_file=${start_shells_path}.createScript.sh
  [ -e $createScript_file ] && { echo -e "\033[1;32m ${createScript_file} 创建连接辅助脚本已创建\033[0m";return; }
  # 询问是否创建 createLink 文件
  alert "是否创建连接辅助脚本（yes/no)：" "no" "yes"
  [ 0 != $? ] && return
  cat >$createScript_file<<\EOF
#!/bin/bash
# 如果你不会使用 ln 命令创建连接文件，运行本脚本，根据提示，可以在当前目录下创建软连接文件
# 交互函数
alert(){
  while :; do
    echo -e " \e[1;33m $1 \e[0m"
    read tmp
    tmp=`echo $tmp | tr [:upper:] [:lower:]`
    if [ $tmp == "$2" ];then
      return 1
    elif [ $tmp == "$3" ];then
      return 0;
    else
      echo -e "\033[1;31m 输入有误，请重新输入 \033[0m"
    fi
  done
}
while :;do
  # 判断调用的脚本是否需要传参
  alert "您创建连接的脚本是否需要传参，或者命令中含有(nohup);(yes/no)" "no" "yes"
  if [ 0 -eq $? ];then
    echo -e "\e[1;33m 请输入要创建链接的启动脚本的完整命令（请使用绝对路径）\e[0m"
    echo -e "\e[1;33m 例如：nohup /data/tools/zookeepr/bin/dispatch &\e[0m"
    echo -e "\e[1;33m 暂不支持输入多个脚本\e[0m"
    echo -ne "\e[33;5m:\e[0m"
    while :;do
      read -e cmd
      echo $cmd | grep -q "\-jar /"
      if [ $? == 0 ];then
        break
      fi
	  echo $cmd | grep -q "nohup /"
	  if [ $? == 0 ];then
        break
      fi
      echo -e "\e[1;31m 请使用绝对路径\e[0m"
      echo -ne "\e[33;5m:\e[0m"
    done
    echo -e "\e[1;33m 请输入要生成的目标文件名,以.sh结尾; 文件名作为 ps 时识别服务的关键字使用，请不要乱起：\e[0m"
    read dest_file_name
    echo '#!/bin/bash' >> ./$dest_file_name
    echo $cmd| grep -q "nohup"
    if [ $? -eq 0 ];then
      #logfile=$(echo $cmd | sed -E 's#^[^/]*([^[:blank:]]*/).*#\1nohup.out#g')
      DIR=$(echo $cmd | sed -E 's#^[^/]*[[:blank:]](/[^[:blank:]]*/).*#\1#g')
      logfile=${DIR}nohup.out
      cmd=${cmd/%'&'/>>"${logfile} 2>&1 &" }
    fi 
    echo "cd $DIR" >> ./$dest_file_name
    echo $cmd >> ./$dest_file_name
	chmod +x $dest_file_name
  else
    echo -e "\e[1;33m 请输入要创建链接的命令或脚本 \e[0m"
    echo -e "\e[1;33m 例如：/data/tools/nifi/start.sh \e[0m"
    #echo -e "\e[1;33m 也可以使用空格分割输入多个脚本：/data/tools/nifi/start.sh /data/tools/zookeepr/bin/zkServer.sh \e[0m"
    echo -ne "\e[33;5m:\e[0m"
	while :;do
      read -e cmd
	  echo $cmd | grep -E -q "^/"
      if [ $? == 0 ];then
        break
      fi	  
	  echo -e "\e[1;31m 请使用绝对路径\e[0m"
      echo -ne "\e[33;5m:\e[0m"
	done
	echo -e "\e[1;33m 请输入创建后的连接名，比如：bj-dispatch.sh \e[0m"
	echo -ne "\e[33;5m:\e[0m"
	read -e dest_file_name
    ln -s ${cmd} ./$dest_file_name
  fi
  alert "是否继续（yes/no)" "no" "yes"
  [ 0 != $? ] && break;
done
EOF
  chmod +x $createScript_file
  _green " 稍后可以通过 $start_shells_path 目录下的 .createScript.sh 创建脚本连接\n" 
}

# 创建check_shell示例
## 使用 init 参数时，在 check_shells_path 指定的目录中 生成.demo.sh 的示例文件
## 需要使用全局变量 check_shells_path
########################################
create_checkdemo(){
  # 检查demo文件是否存在
  local demo_file=${check_shells_path}.demo.sh
  [ -e $demo_file ] && { echo -e "\033[1;32m ${demo_file} 检测示例脚本已创建\033[0m";return; }
  # 询问是否创建demo 文件
  alert "是否创建检测进程脚本的demo文件（yes/no)：" "no" "yes"
  [ 0 != $? ] && return
  cat>$demo_file<<\EOF
#!/bin/bash
# check_shell 示例脚本
############ 变量设置部分 ###########
# 设置检测的进程名
process_name="进程"

############demo 检测结果返回函数 ############
# 如果调用 check_result fail 会立刻退出脚本并提示检测失败;
# check_result success 不会立刻退出，如果后面还有代码将继续检测；所以check_result success 一定要在脚本的最后执行
check_result(){
    local result=`echo $1 | tr [:upper:] [:lower:]`

    # 如果检测参数为fail 表示检测失败; success 表示成功
    if [ $result == "fail" ]; then
        echo "$process_name" >> ./custom_check_fail
        if [ -f ../PID/${process_name}.pid ];then
          local PID=`cat ../PID/${process_name}.pid`
          kill -9 $PID
        fi
        exit 1
    elif [ $result == "success" ];then
        echo "$process_name" >> ./custom_check_success
    else
        echo -e "\033[1;31m check_result 函数语法错误 \033[0m"
    fi
}


############ demo main (进程检测部分) ############
# 失败示例
## ping 一个服务器,pingm命令执行成功调用 check_result success;  失败则调用 check_result fail
ping server.com.bucunzai
[ 0 -eq $? ] && check_result success || check_result fail

# 成功示例
## 检查是否存在 /root 目录，成功调用 check_result success; 失败则调用 check_result fail
[ -d "/root" ] && check_result success || check_result fail

EOF
  _green "  稍后可以通过 vim ${check_shells_path}.demo.sh 查看自定义检测示例脚本\n"
}


# 创建开机启动的 systemd 脚本
create_systemd_file() {
  cat>/usr/lib/systemd/system/scm.service <<EOF
[Unit]
Description=The startAndCheck-withMonitor server
After=network.target remote-fs.target nss-lookup.target
[Service]
Type=forking
PIDFile=$(pwd)/PID/monitor.pid
ExecStart=$(pwd)/startAndCheckServices-withMonitor.sh monitor
ExecStop=$(pwd)/startAndCheckServices-withMonitor.sh stopmonitor
ExecStartPost=/bin/sleep 0.1
RestartSec=3
PrivateTmp=true
Restart=on-failure
[Install]
WantedBy=multi-user.target
EOF
}

create_alias(){
  #local cmd=`echo $0 | grep -o "[^/]*$"`
  local cmd=`basename $0`
  echo -e "alias scmcheck="\'"$(pwd)/${cmd} check"\' >> /etc/profile.d/scm.sh
  echo -e "alias scmstart="\'"$(pwd)/${cmd} start"\' >> /etc/profile.d/scm.sh
  echo -e "alias scmmonitor="\'"$(pwd)/${cmd} monitor"\' >> /etc/profile.d/scm.sh
  echo -e "alias scmstopmonitor="\'"$(pwd)/${cmd} stopmonitor"\' >> /etc/profile.d/scm.sh
  echo -e "alias scmlog="\'"$(pwd)/${cmd} log"\' >> /etc/profile.d/scm.sh
  echo -e "alias scmonline="\'"$(pwd)/${cmd} online"\' >> /etc/profile.d/scm.sh
  echo -e "alias scmoffline="\'"$(pwd)/${cmd} offline"\' >> /etc/profile.d/scm.sh
  echo -e "alias scmhelp="\'"$(pwd)/${cmd} help"\' >> /etc/profile.d/scm.sh
  _green " 命令别名已创建\n"
}

create_scmutils(){
  \cp dependency/utils.sh /etc/profile.d/scmutils.sh
}

