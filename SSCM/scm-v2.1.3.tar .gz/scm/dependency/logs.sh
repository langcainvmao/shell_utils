#!bin/bash
## 日志相关的函数库


# 日志功能的开启
## 需要使用全局变量 conf_file
##########################################################
enable_log(){
  # 判断write_log是否开启状态
  grep -q '^LOG_THRESHOLD=5$' $conf_file
  # 如果没有开启，则询问是否开启
  if [ 0 = $? ]; then
    alert "是否开启日志功能（yes/no）：" "no" "yes"
    [ 0 != $? ] && return
    sed  -i  's/^LOG_THRESHOLD=5$/LOG_THRESHOLD=0/' $conf_file
  fi
  _green " 日志功能已开启\n"
}

# 日志功能的关闭
## 需要使用全局变量 conf_file
##########################################################
disable_log(){
  # 判断write_log是否开启状态
  grep -q '^LOG_THRESHOLD=0$' $conf_file
  # 如果没有开启，则询问是否开启
  if [ 0 = $? ]; then
    alert "是否关闭日志功能（yes/no）：" "no" "yes"
    [ 0 != $? ] && return
    sed  -i  's/^LOG_THRESHOLD=0$/LOG_THRESHOLD=5/' $conf_file
    _green " 日志功能已关闭\n"
  fi
}

# 读取日志函数
## 需要传递一个参数
## $1 log文件的路径和文件名
## 示例 read_log "./conf/startAndCheck-withMonitor.conf"
read_log(){
  if [ -z $1 ]; then
    if ! [ -e $check_log_name ];then
      _red "日志文件还未创建\n"
      exit
    fi
    tail -n 200 $check_log_name
    return
  else
    tail -n 200 $1
  fi
}

# 日志切割函数
## $1 要切割的 log文件
## 示例 cut_log $log_dir/check_result.log
############################
cut_log(){
  #enable_log
  local time1=`date +'%Y%m%d%H%M%S'`
  mv $1 ${1%.log}_${time1}.bak
  /bin/bash -c " `ls -t ${1%.log}_*.bak| awk '5<NR{printf("rm -fr %s\n", $1)}'`"
}
