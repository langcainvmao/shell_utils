#!/bin/bash
## 服务启动、检测监控脚本
## 作者： 赵文光
## 联系方式: 13810398818
## 详见 readme.txt


################ 必须要最执行的语句 ##################

## 工作目录
work_dir="./"

# 如果 work_dir 没有初始化（默认值是./），提示用户初始化
echo "$work_dir" | grep -q "^\./$"
if [ $? -eq 0 ] && [ "$1" != "init" ];then
  echo -e "\e[1;031m 请先到本脚本所在目录使用 init 选项初始化\e[0m"
  exit 1
fi

#################### include #####################
. ${work_dir}/dependency/variables.sh 
. ${work_dir}/dependency/utils.sh
. ${work_dir}/dependency/logs.sh
. ${work_dir}/dependency/createFile.sh
. ${work_dir}/dependency/startAndStop.sh
. ${work_dir}/dependency/checkServices.sh
. ${work_dir}/dependency/monitor.sh
. ${work_dir}/dependency/setAndReset.sh
. ${work_dir}/dependency/maintain.sh





################################
############  main  ############
################################
 
# 判断是否在主脚本所在的目录（因为有些变量用到了相对路径）
#isRunning_at_right_dir


# 进入到工作目录
#cd $work_dir

# 将选项统一转换成大写
param1=`to_upper_case $1`

# 根据参数的内容判断是启动并检测服务，或者只是检测服务,或者只是初始化（创建目录）
case $param1 in
  START|"")
    # 启动服务列表里面的服务
    # $2 是一个陷阱，用来判断是否有多余的参数
    start_services $2
    ;&
  CHECK)
    # 检查服务列表里面的服务
    shift
    check_services $@
    ;;
  INIT)
    init
    ;;
  RESET)
    reset_config
    ;;
  LOG)
    read_log $2
    ;;
  MONITOR)
    monitor $0
    ;;
  STOPMONITOR)
    stop_monitor $0
    ;;
  ONLINE)
    shift
    online $*
    ;;
  OFFLINE)
    shift
    offline $*
    ;;
  STOP)
    stop_all
    ;;
    #TELNET)
        # shift
        # scm-telnet.sh $@
        # ;;
  *)
    describe ${work_dir}/readme.txt
esac 
